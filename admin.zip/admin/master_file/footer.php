<footer class="main-footer">
    <div class="footer-left">
        Dibuat Oleh Kelompok 1
    </div>
    <div class="footer-right">
        2024
    </div>
</footer>